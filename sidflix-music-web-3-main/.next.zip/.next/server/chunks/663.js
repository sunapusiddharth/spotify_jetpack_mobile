"use strict";
exports.id = 663;
exports.ids = [663];
exports.modules = {

/***/ 6086:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   t: () => (/* binding */ FeaturedCarousel2)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks_windowDimensio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3988);







function FeaturedCarousel2(props) {
    // const { width } = useWindowDimensions()
    // const {carouseSettings} = React.useContext(AppContext) as AppContextType
    // const [_carouseSettings, setCarouseSettings] = React.useState<Settings>(carouseSettings);
    // React.useEffect(() => {
    //     if (width < 600) {
    //       setCarouseSettings({ ...carouseSettings, slidesToShow: 1, slidesToScroll: 1 })
    //     }
    //     if (width < 1024 && width > 600) {
    //       setCarouseSettings({ ...carouseSettings, slidesToShow: 3, slidesToScroll: 3 })
    //     }
    //     if (width >= 1024 ) {
    //       setCarouseSettings({ ...carouseSettings, 
    //         slidesToShow: 3, slidesToScroll: 1
    //      })
    //     }
    //   }, [width])
    const { width, height } = (0,_hooks_windowDimensio__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        className: "carousel-container",
        style: {
            marginTop: 40
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
            swipeToSlide: true,
            className: "center",
            centerMode: true,
            infinite: true,
            centerPadding: "60px",
            slidesToShow: 3,
            speed: 500,
            autoplay: true,
            children: props.data?.map((x)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: "/playlist/" + x.id,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
                        className: "radio_carousel_card",
                        sx: {
                            // backgroundColor: 'black !important',
                            width: 600,
                            height: 400,
                            // height:'100%',width:'100%',
                            display: "flex",
                            flexDirection: "column",
                            alignContent: "center",
                            alignItems: "center",
                            justifyContent: " space-around",
                            "&:hover": {
                                backgroundColor: "#282626",
                                cursor: "pointer"
                            }
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            sx: {
                                position: "relative",
                                height: "100%",
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    src: x.image || "/sample.jpg",
                                    width: 590,
                                    height: 400,
                                    alt: ""
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                    sx: {
                                        position: "absolute",
                                        bottom: 0,
                                        left: 0,
                                        width: "100%",
                                        bgcolor: "rgba(0, 0, 0, 0.54)",
                                        color: "white",
                                        padding: "13px",
                                        fontSize: "small"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        children: x.title
                                    })
                                })
                            ]
                        })
                    })
                }, "carousel-fresh0rela-" + x.id))
        })
    });
}


/***/ }),

/***/ 4254:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ RadioStationCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_4__]);
_pages_app__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function CardComp({ station }) {
    const { setStation } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_pages_app__WEBPACK_IMPORTED_MODULE_4__.AppContext);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "img_container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Card, {
                className: "radio_carousel_card",
                sx: {
                    backgroundColor: "black !important",
                    width: 150,
                    height: 200,
                    display: "flex",
                    flexDirection: "column",
                    alignContent: "center",
                    alignItems: "center",
                    justifyContent: " space-around",
                    "&:hover": {
                        backgroundColor: "#282626",
                        cursor: "pointer"
                    }
                },
                onClick: ()=>setStation(station),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                        src: station.favicon || "/sample.jpg",
                        width: 150,
                        height: 150,
                        alt: ""
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/play_icon.png",
                        className: "play"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_1___default()), {
                        sx: {
                            fontSize: "small"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                            variant: "caption",
                            textAlign: "center",
                            children: station.name
                        })
                    })
                ]
            })
        })
    });
}
function moviePropsAreEqual(prevProps, nextProps) {
    return prevProps === nextProps;
}
const RadioStationCard = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_6__.memo)(CardComp, moviePropsAreEqual);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 349:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ RadioCarousel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RadioCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4254);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_RadioCard__WEBPACK_IMPORTED_MODULE_2__, _pages_app__WEBPACK_IMPORTED_MODULE_4__]);
([_RadioCard__WEBPACK_IMPORTED_MODULE_2__, _pages_app__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function RadioCarousel(props) {
    const { carouseSettings } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_pages_app__WEBPACK_IMPORTED_MODULE_4__.AppContext);
    const cards = props.data.data || [];
    if (!cards.length) return null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            background: "black !important",
            marginTop: "1%"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                justifyContent: "space-between",
                sx: {
                    backgroundColor: "black"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        variant: "subtitle2",
                        children: props.data.label
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                className: "container",
                marginTop: "1%",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                    ...carouseSettings,
                    children: cards.map((x, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RadioCard__WEBPACK_IMPORTED_MODULE_2__/* .RadioStationCard */ .I, {
                            station: x
                        }, "station-card" + x.id + index))
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomePage: () => (/* binding */ HomePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   hasNavigationCSR: () => (/* binding */ hasNavigationCSR)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3534);
/* harmony import */ var _mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1775);
/* harmony import */ var _components_home_Carousel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2657);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4178);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_home_FeaturedCarousel2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6086);
/* harmony import */ var _mui_icons_material_PlayArrow__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9272);
/* harmony import */ var _mui_icons_material_PlayArrow__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlayArrow__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_radio_RadioCarousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(349);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1279);
/* harmony import */ var _components_podcast_PodcastCarousel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6169);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_home_Carousel__WEBPACK_IMPORTED_MODULE_7__, _app__WEBPACK_IMPORTED_MODULE_8__, _components_radio_RadioCarousel__WEBPACK_IMPORTED_MODULE_12__, _components_podcast_PodcastCarousel__WEBPACK_IMPORTED_MODULE_13__]);
([_components_home_Carousel__WEBPACK_IMPORTED_MODULE_7__, _app__WEBPACK_IMPORTED_MODULE_8__, _components_radio_RadioCarousel__WEBPACK_IMPORTED_MODULE_12__, _components_podcast_PodcastCarousel__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const HomeComp = ({})=>{
    const { data: session } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)();
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (!session) {
            next_router__WEBPACK_IMPORTED_MODULE_4___default().push("/auth/signin");
        }
    }, []);
    const { user, setCurrentSong } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_app__WEBPACK_IMPORTED_MODULE_8__.AppContext);
    const { isSuccess, isLoading, isError, error, data, fetchNextPage, isFetchingNextPage } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useInfiniteQuery)([
        "homepage"
    ], async ({ pageParam = 1 })=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .fetchHomePageData */ .oJ)(user?.id, pageParam), {
        getNextPageParam: (lastPage, pages)=>{
            return lastPage.page + 1;
        },
        keepPreviousData: true,
        refetchOnMount: false,
        refetchOnWindowFocus: false,
        staleTime: 9000,
        cacheTime: 90000
    });
    const { data: topStationsByVotesData, isLoading: loading0 } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "browseStationsByCountry",
        "IN",
        1
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .browseStationsByCountry */ .Q2)("IN", 1));
    const { data: editorsPlayListData, isLoading: loading234 } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "editor_playlist"
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .getEditorsPlayList */ .HV)(10));
    const { data: topArtists, isLoading: loadingTopArtists } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "top_artists"
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .fetchTopArtists */ .KN)());
    const { data: topScoringTracksForUser, isLoading: loadingtopTracksForuser } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "topScoringTracksForUser"
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .getTopScoringSongsForuser */ .Ym)(user?.id, 10));
    const { data: top10PodcastsData } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "top_podcasts"
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .browsePodcasts */ .Ev)(1));
    const artCards = topArtists?.length ? (0,_utils__WEBPACK_IMPORTED_MODULE_14__/* .uniqueBy */ .uw)("id", topArtists)?.map((x)=>({
            image: x.image,
            id: x.id,
            title: x.title,
            subtitle: "",
            type: "artists_card",
            path: "/artist/" + x.id,
            song: null
        })) : [];
    const artists = {
        cardType: "artist_card",
        label: "Top Artists",
        path: "/artist",
        //@ts-expect-error
        cards: artCards,
        id: "top_artists"
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3___default()), {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                sx: {
                    overflowY: "scroll",
                    paddingX: 3
                },
                children: [
                    isError && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                        children: [
                            " ",
                            "Error!" + error
                        ]
                    }),
                    isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "Loading..."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_FeaturedCarousel2__WEBPACK_IMPORTED_MODULE_10__/* .FeaturedCarousel2 */ .t, {
                        data: editorsPlayListData?.cards || []
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_radio_RadioCarousel__WEBPACK_IMPORTED_MODULE_12__/* .RadioCarousel */ .F, {
                        data: {
                            label: "Listen to Top Radio Stations ",
                            data: topStationsByVotesData?.results || []
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                        sx: {
                            paddingTop: 3
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_Carousel__WEBPACK_IMPORTED_MODULE_7__/* .CardsListing */ .V, {
                            data: artists
                        }, "cardlisitng-" + "top_artists1")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_podcast_PodcastCarousel__WEBPACK_IMPORTED_MODULE_13__/* .PodcastCarousel */ .Y, {
                        data: {
                            label: "Top Podcasts",
                            cards: top10PodcastsData?.results || []
                        },
                        genreid: ""
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                        container: true,
                        justifyContent: "space-between",
                        className: "songs_container",
                        children: topScoringTracksForUser?.length && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                            item: true,
                            sx: {
                                width: "50%",
                                margin: 2
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                    variant: "subtitle2",
                                    sx: {
                                        fontVariant: "all-small-caps"
                                    },
                                    children: "Top Songs"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.List, {
                                    className: "weekly_songs",
                                    sx: {
                                        marginBottom: "3%"
                                    },
                                    children: topScoringTracksForUser?.map((x, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {
                                            className: "weekly_song",
                                            onClick: ()=>setCurrentSong(x),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "title",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: index
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                                            variant: "subtitle2",
                                                            children: x.name
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                                            variant: "caption",
                                                            children: x.artists?.map((t)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Link, {
                                                                    href: "/artist" + t.id,
                                                                    children: t.title
                                                                }, "top_songs_score_artist-" + t.id))
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlayArrow__WEBPACK_IMPORTED_MODULE_11___default()), {})
                                                })
                                            ]
                                        }, "top_songs_score" + x.id))
                                })
                            ]
                        })
                    }),
                    isSuccess && data.pages?.map((page)=>page.results.map((x, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                                sx: {
                                    paddingTop: 3
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_Carousel__WEBPACK_IMPORTED_MODULE_7__/* .CardsListing */ .V, {
                                    data: x
                                }, "cardlisitng-" + x.id)
                            }, x.id + i))),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "btn-container",
                        style: {
                            textAlign: "center",
                            marginTop: "2%"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                            variant: "contained",
                            onClick: ()=>fetchNextPage(),
                            size: "small",
                            sx: {
                                color: "white",
                                background: "purple",
                                fontWeight: "bolder",
                                opacity: 0.9
                            },
                            children: isFetchingNextPage ? "Loading..." : "Load More"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: isLoading && !isFetchingNextPage ? "Fetching..." : null
                    })
                ]
            })
        })
    });
};
function moviePropsAreEqual(prevProps, nextProps) {
    // //console.log("Props validation",prevProps === nextProps,prevProps ,nextProps)
    return JSON.stringify(prevProps) === JSON.stringify(nextProps);
}
const HomePage = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.memo(HomeComp, moviePropsAreEqual);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePage);
const hasNavigationCSR = (next)=>async (ctx)=>{
        if (ctx.req.url?.startsWith("/_next")) {
            return {
                props: {}
            };
        }
        return next?.(ctx);
    };
const getServerSideProps = hasNavigationCSR(async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.getSession)(context);
    const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClient();
    //@ts-ignore
    const userid = session?.user?.id;
    if (!queryClient.getQueryData([
        "homepage"
    ])) {
        await queryClient.prefetchInfiniteQuery([
            "homepage"
        ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_6__/* .fetchHomePageData */ .oJ)(userid, 1));
        await Promise.all([
            queryClient.prefetchQuery([
                "browseStationsByCountry",
                "IN",
                1
            ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .browseStationsByCountry */ .Q2)("IN", 1)),
            queryClient.prefetchQuery([
                "editor_playlist"
            ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_6__/* .getEditorsPlayList */ .HV)(10)),
            queryClient.prefetchQuery([
                "top_artists"
            ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_6__/* .fetchTopArtists */ .KN)()),
            queryClient.prefetchQuery([
                "topScoringTracksForUser"
            ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_6__/* .getTopScoringSongsForuser */ .Ym)(userid, 10)),
            queryClient.prefetchQuery([
                "top_podcasts"
            ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_6__/* .browsePodcasts */ .Ev)(1))
        ]);
    }
    return {
        props: {
            dehydratedState: JSON.parse(JSON.stringify((0,react_query__WEBPACK_IMPORTED_MODULE_2__.dehydrate)(queryClient)))
        }
    };
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;