exports.id = 178;
exports.ids = [178];
exports.modules = {

/***/ 1775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $m: () => (/* binding */ getNextQueueItem),
/* harmony export */   AP: () => (/* binding */ addSongToPlaylist),
/* harmony export */   B7: () => (/* binding */ requestPodcastEpisodesPopulation),
/* harmony export */   Ev: () => (/* binding */ browsePodcasts),
/* harmony export */   FG: () => (/* binding */ getPrevQueueItem),
/* harmony export */   FQ: () => (/* binding */ fetchUserData),
/* harmony export */   FX: () => (/* binding */ getLastPlayedStations),
/* harmony export */   HC: () => (/* binding */ findSongsByFileNames),
/* harmony export */   HV: () => (/* binding */ getEditorsPlayList),
/* harmony export */   Ix: () => (/* binding */ uploadImage),
/* harmony export */   Jh: () => (/* binding */ getStreamLink),
/* harmony export */   Jo: () => (/* binding */ browseTop10PlaylistCollectionByGenre),
/* harmony export */   KN: () => (/* binding */ fetchTopArtists),
/* harmony export */   Ks: () => (/* binding */ getAllGenres),
/* harmony export */   LG: () => (/* binding */ browseStationsByCountryAndGenre),
/* harmony export */   Lz: () => (/* binding */ fetchAlbum),
/* harmony export */   M2: () => (/* binding */ fetchPlaylistData),
/* harmony export */   N3: () => (/* binding */ getUserPlaylist),
/* harmony export */   Q2: () => (/* binding */ browseStationsByCountry),
/* harmony export */   QN: () => (/* binding */ trendingStations),
/* harmony export */   S9: () => (/* binding */ userListenedPodcasts),
/* harmony export */   Sk: () => (/* binding */ deleteSong),
/* harmony export */   TM: () => (/* binding */ fetchPlaylistCollection),
/* harmony export */   UL: () => (/* binding */ getuserLikedPlcs),
/* harmony export */   Vg: () => (/* binding */ markAsBadLink),
/* harmony export */   Vj: () => (/* binding */ getAllRadioCountries),
/* harmony export */   Vt: () => (/* binding */ fetchAllArtistPlaylistsCollection),
/* harmony export */   WM: () => (/* binding */ getPodcastDetails),
/* harmony export */   XM: () => (/* binding */ addPlayListToQueue),
/* harmony export */   YB: () => (/* binding */ fetchArtistData),
/* harmony export */   YD: () => (/* binding */ getAllPodcastGenres),
/* harmony export */   YE: () => (/* binding */ getFav),
/* harmony export */   Ym: () => (/* binding */ getTopScoringSongsForuser),
/* harmony export */   Z4: () => (/* binding */ getTopFollowingPlayListCollections),
/* harmony export */   Zn: () => (/* binding */ findSongByName),
/* harmony export */   _o: () => (/* binding */ getPodcastEpisoes),
/* harmony export */   aF: () => (/* binding */ fetchAllArtistPlaylists),
/* harmony export */   b4: () => (/* binding */ uploadMultipleSongs),
/* harmony export */   bt: () => (/* binding */ userListenedStation),
/* harmony export */   dA: () => (/* binding */ getLastPlc),
/* harmony export */   dL: () => (/* binding */ getLatestPlayListCollections),
/* harmony export */   fe: () => (/* binding */ searchAll),
/* harmony export */   g8: () => (/* binding */ getAllAvailableSongs),
/* harmony export */   gH: () => (/* binding */ liekdislikesong),
/* harmony export */   gd: () => (/* binding */ getUserLikedPodcasts),
/* harmony export */   gx: () => (/* binding */ fetchAllPlayListData),
/* harmony export */   hH: () => (/* binding */ requestTrackAddition),
/* harmony export */   h_: () => (/* binding */ liekdislikestation),
/* harmony export */   iA: () => (/* binding */ getAllSongs),
/* harmony export */   jV: () => (/* binding */ deletePlayList),
/* harmony export */   kA: () => (/* binding */ fetchAllArtistData),
/* harmony export */   kt: () => (/* binding */ getTop10PodcastsByGenres),
/* harmony export */   oJ: () => (/* binding */ fetchHomePageData),
/* harmony export */   p_: () => (/* binding */ fetchRadio),
/* harmony export */   qj: () => (/* binding */ userLikedStatison),
/* harmony export */   ru: () => (/* binding */ browsePodcastsByGenre),
/* harmony export */   se: () => (/* binding */ browsePlayListCollectionByGenre),
/* harmony export */   si: () => (/* binding */ topPodcastsByUserActivity),
/* harmony export */   vy: () => (/* binding */ fetchQueueData),
/* harmony export */   xH: () => (/* binding */ getSong),
/* harmony export */   xd: () => (/* binding */ addToQueue),
/* harmony export */   zO: () => (/* binding */ requestSpotifysearch),
/* harmony export */   zQ: () => (/* binding */ createNewPlaylist)
/* harmony export */ });
/* unused harmony exports freshAlbums, fetchFeaturedHomePageData, fetchTopPlaylistCollectionData, userLikedPlc, userListenedPlc, fetchPlcGenres, getTopScoringSongs, fetchArtistsSongs, fetchAllPlayListCollections, removeFromQueue, followPlayList, unFollowPlayList, liekdislikepodcast, addS3Link, findSongsByIds, getAllBadLink, getTop10StationsByGenres, userLikedPodacsts */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

// axios.defaults.headers.get['Content-Type'] ='application/json';
const content_base_url = "http://131.153.22.221/api/spotify";
//  const content_base_url = 'http://ec2-13-232-179-174.ap-south-1.compute.amazonaws.com/api/spotify-content-service'
// const search_base_url = 'http://65.2.131.218/api/spotify-search'
// const content_base_url = 'http://localhost:7001'
const search_base_url = content_base_url;
const fetchUserData = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/users/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchHomePageData = async (id, page)=>{
    if (!id) return {
        page: page,
        results: []
    };
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/users/${id}/home/${page}`);
    console.log("homepagedata", page);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const fetchPlaylistData = async (id)=>{
    if (!id) return undefined;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchAlbum = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/album/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const freshAlbums = async ()=>{
    const res = await axios.get(`${content_base_url}/album/freshAlbums`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchFeaturedHomePageData = async (id)=>{
    const res = await axios.get(`${content_base_url}/album/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchTopPlaylistCollectionData = async ()=>{
    const res = await axios.get(`${content_base_url}/playlist_collection/top/10/0`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchPlaylistCollection = async (id)=>{
    if (!id) return null;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getuserLikedPlcs = async (userid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/${userid}/liked_plc`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getTopFollowingPlayListCollections = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/getTopFollowingPlayListCollections`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getEditorsPlayList = async (limit)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/getEditorsPlayList/${limit}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getLatestPlayListCollections = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/getLatestPlayListCollections`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getLastPlc = async (userid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/${userid}/listened_plc/last_played`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const userLikedPlc = async (userid, stationid)=>{
    const res = await axios.put(`${content_base_url}/playlist_collection/${userid}/liked_plc/${stationid}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const userListenedPlc = async (userid, stationid, duration)=>{
    const res = await axios.put(`${content_base_url}/playlist_collection/${userid}/listened_plc/${stationid}/${duration}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchPlcGenres = async (userid)=>{
    const res = await axios.get(`${search_base_url}/search/${userid}/plc_genres`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
//End playlist_collection
const fetchQueueData = async (userid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/tracks/${userid}/queue`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getTopScoringSongsForuser = async (userid, limit)=>{
    if (!userid) return null;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/tracks/top_scoring_songs/${userid}/${limit}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getTopScoringSongs = async (limit)=>{
    const res = await axios.get(`${content_base_url}/tracks/top_scoring_songs/${limit}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getNextQueueItem = async (userid)=>{
    console.log("getNextQueueItem", userid);
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/tracks/${userid}/next_item_in_queue`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getPrevQueueItem = async (userid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/tracks/${userid}/prev_item_in_queue`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchArtistsSongs = async (id, page)=>{
    if (!id) return {
        page: page,
        results: []
    };
    const res = await axios.get(`${content_base_url}/artist/songs/${id}/${page}`);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const fetchTopArtists = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/artist/top`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// export const fetchArtistTopTracks = async (id: string): Promise<SongType[] | null> => {
//   const res = await axios.get<SongType[]>(`${content_base_url}/artist/${id}/top_tracks`);
//   if (res.status === 200) {
//     return res.data;
//   }
//   throw new Error('Network response not ok');
// };
// export const fetchArtistSingles = async (id: string): Promise<SongType[] | null> => {
//   const res = await axios.get<SongType[]>(`${content_base_url}/artist/${id}/singles`);
//   if (res.status === 200) {
//     return res.data;
//   }
//   throw new Error('Network response not ok');
// };
// export const fetchSimilarArtists = async (id: string, limit: number): Promise<ArtistType[] | null> => {
//   const res = await axios.get<ArtistType[]>(`${content_base_url}/artist/${id}/similar`);
//   if (res.status === 200) {
//     return res.data;
//   }
//   throw new Error('Network response not ok');
// };
const fetchAllArtistPlaylists = async (id, limit, skip)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/artist/${id}/playlists/${limit}/${skip}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchAllArtistPlaylistsCollection = async (id, limit, skip)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/artist/${id}/playlists_collection/${limit}/${skip}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchArtistData = async (id)=>{
    console.log("Aritst quert", id);
    if (!id) return null;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/artist/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchAllArtistData = async (page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/artist/all/${page}`);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const fetchAllPlayListData = async (page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/album/all/${page}`);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const fetchAllPlayListCollections = async (page)=>{
    const res = await axios.get(`${content_base_url}/playlist_collection/all/${page}`);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const browsePlayListCollectionByGenre = async (genre, page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/browseByGenre/${page}?genre=${genre}`);
    if (res.status === 200) {
        return {
            page: res.data.page,
            results: res.data.results
        };
    }
    throw new Error("Network response not ok");
};
const browseTop10PlaylistCollectionByGenre = async (userid, page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist_collection/browseTop10PlaylistCollectionByGenre/${userid}/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}
const randomElement = (data)=>data[Math.floor(Math.random() * data.length)];
const addToQueue = async (id, trackid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/tracks/${id}/${trackid}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const addPlayListToQueue = async (id, trackids)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/tracks/${id}/add-multiple`, {
        songs: trackids
    });
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const removeFromQueue = async (id, trackid)=>{
    const res = await axios.delete(`${content_base_url}/tracks/${id}/${trackid}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const followPlayList = async (id, playlistid)=>{
    const res = await axios.put(`${content_base_url}/users/${id}/${playlistid}/follow-playlist`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const unFollowPlayList = async (id, playlistid)=>{
    const res = await axios.put(`${content_base_url}/users/${id}/${playlistid}/unfollow-playlist`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getSong = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/tracks/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// export const updateSong = async (song: SongType) => {
//   const res = await axios.put<SongType>(`${content_base_url}/tracks/${song.id}`, {
//     song
//   });
//   if (res.status === 201) {
//     return res.data;
//   }
//   throw new Error('Network response not ok');
// };
const deleteSong = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`${content_base_url}/tracks/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const liekdislikesong = async (id, likedislike, trackid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/users/${id}/likedislike/song/${trackid}/${likedislike}`);
    return res.data;
    throw new Error("Network response not ok");
};
const liekdislikestation = async (id, likedislike, trackid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/users/${id}/likedislike/radio/${trackid}/${likedislike}`);
    return res.data;
    throw new Error("Network response not ok");
};
const liekdislikepodcast = async (id, likedislike, trackid)=>{
    const res = await axios.put(`${content_base_url}/users/${id}/likedislike/podcast/${trackid}/${likedislike}`);
    return res.data;
    throw new Error("Network response not ok");
};
const addS3Link = async (songid, s3link)=>{
    const res = await axios.put(`${content_base_url}/tracks/${songid}/addS3Link/${s3link}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const findSongsByFileNames = async (userid, names)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/tracks/findmultiplebynames/${userid}`, {
        names
    });
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const findSongsByIds = async (userid, ids)=>{
    const res = await axios.post(`${content_base_url}/tracks/findmultiplebyids/${userid}`, {
        ids
    });
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const findSongByName = async (userid, names)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/tracks/findbyname/${userid}`, {
        names
    });
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
function chunk(arr, len) {
    var chunks = [], i = 0, n = arr.length;
    while(i < n){
        chunks.push(arr.slice(i, i += len));
    }
    return chunks;
}
const uploadMultipleSongs = async (songfiles)=>{
    //first upload files
    // const chunks: {
    //   song: any;
    //   file: File;
    // }[][] = chunk(songfiles, 10)
    const promises = [];
    songfiles.map((songFile)=>promises.push(abcd(songFile)));
    const keys2 = await Promise.all(promises);
    //@ts-ignore
    const keys = keys2.filter((x)=>x != undefined);
    console.log("Keys recieved", keys, keys2);
    const allNewSongs = songfiles.filter((x)=>x.song.results?.id).map((x, i)=>({
            ...x.song,
            results: Array.isArray(x.song.results) ? x.song.results[0] : x.song.results,
            s3link: keys.find((y)=>y.id == x.song.results?.id)?.key || ""
        }));
    const res2 = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/tracks/uploadAll/`, {
        songsFileMap: allNewSongs
    });
    if (res2.status == 201) {
        return res2.data;
    }
    throw new Error("Network response not ok");
};
async function abcd(songFile) {
    const formData = new FormData();
    formData.append("audiofiles", songFile.file);
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`http://localhost:7004/transcode/uploadAll/`, formData, {
        headers: {
            "Content-Type": "multipart/form-data"
        }
    });
    if (res.status == 201) {
        const key = typeof res.data == "string" ? res.data : typeof res.data == "object" ? res.data.key : null;
        console.log("key", key, songFile);
        if (key && songFile.song.results?.id) return {
            id: songFile.song.results.id,
            key
        };
    }
}
const uploadImage = async (file)=>{
    const formData = new FormData();
    formData.append("image", file);
    const res2 = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/playlist/uploadImage/`, formData, {
        headers: {
            "Content-Type": "multipart/form-data"
        }
    });
    if (res2.status == 201) {
        return res2.data;
    }
    throw new Error("Network response not ok");
};
const searchAll = async (query, type, page)=>{
    if (!query) return undefined;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${search_base_url}/search/${"test"}/${query}/${type || "null"}/${page}`);
    if (res.status == 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const requestSpotifysearch = async (userid, query, page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/search/${userid}/${query}/${""}/${page}`);
    if (res.status == 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const requestTrackAddition = async (userid, songid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/tracks/requestTrackAddition/${userid}/${songid}`);
    if (res.status == 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const requestPodcastEpisodesPopulation = async (userid, songid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/podcast/requestPodcastEpisodesPopulation/${userid}/${songid}`);
    if (res.status == 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// Playlist
const createNewPlaylist = async (userid, name, image)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/playlist/${userid}/create-new-playlist/${name}`, {
        image
    });
    if (res.status == 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const addSongToPlaylist = async (userid, playlists, songid, posterpath)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/playlist/${userid}/${songid}`, {
        playlists,
        posterpath
    });
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getUserPlaylist = async (userid)=>{
    if (!userid) return [];
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist/${userid}/playlists`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getFav = async (user_id)=>{
    if (!user_id) return undefined;
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/playlist/${user_id}/fav`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const deletePlayList = async (userid, playlistid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`${content_base_url}/playlist/${userid}/${playlistid}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getStreamLink = async (s3link, userid, id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/stream/`, {
        userid: userid,
        id: id,
        s3link: s3link
    });
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getAllAvailableSongs = async (page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/stream/all_available_songs/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getAllSongs = async (page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/stream/all_songs/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const markAsBadLink = async (id, bad)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${content_base_url}/stream/markbadlink/${id}/${bad}`);
    if (res.status === 201) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getAllBadLink = async ()=>{
    const res = await axios.get(`${content_base_url}/stream/allbadlink`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// Radio 
const userLikedStatison = async (userid)=>{
    if (!userid) return [];
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${userid}/liked_stations`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getTop10StationsByGenres = async (countryCode, genre)=>{
    const res = await axios.get(`${content_base_url}/radio/${countryCode}/getTop10StationsByGenres/${genre}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const browseStationsByCountryAndGenre = async (countryCode, genre, page)=>{
    if (!countryCode) return {
        page: page,
        results: []
    };
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${countryCode}/browseStationsByCountryAndGenre/${page}?genre=${genre}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const browseStationsByCountry = async (countryCode, page)=>{
    if (!countryCode) return {
        page: page,
        results: []
    };
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${countryCode}/browseStationsByCountry/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const trendingStations = async (countryCode)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${countryCode}/trendingStations`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getLastPlayedStations = async (userid)=>{
    if (!userid) return [];
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${userid}/last_played_stations`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const userListenedStation = async (userid, stationid, duration)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/radio/${userid}/listened_station/${stationid}/${duration}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getAllRadioCountries = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/all_countries`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getAllGenres = async (countryCode)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/all_genres/${countryCode}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const fetchRadio = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/radio/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// Podcasts
const getAllPodcastGenres = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/all_genres`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getUserLikedPodcasts = async (userid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/:userid/liked_podcasts`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getTop10PodcastsByGenres = async (genre)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/getTop10PodcastsByGenres/${genre}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
// export const browseTop10Podcasts = async (page: number) => {
//   const res = await axios.get<BrowsePodcastsPageInfo>(`${content_base_url}/podcast/browseTop10PodcastsByGenres/${page}`)
//   if (res.status === 200) {
//     return res.data;
//   }
//   throw new Error('Network response not ok');
// };
const browsePodcastsByGenre = async (genre, page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/browsePodcastsByGenre/${genre}/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const browsePodcasts = async (page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/browse/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const userLikedPodacsts = async (userid, podcastid, episodeid)=>{
    const res = await axios.put(`${content_base_url}/podcast/${userid}/liked_podcast/${podcastid}/${episodeid}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const userListenedPodcasts = async (userid, podcastid, duration, episodeid)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${content_base_url}/podcast/${userid}/listened_station/${podcastid}/${episodeid}/${duration}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getPodcastEpisoes = async (id, page)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/${id}/episodes/${page}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const getPodcastDetails = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/${id}`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};
const topPodcastsByUserActivity = async (id)=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${content_base_url}/podcast/${id}/topPodcastsByUserActivity`);
    if (res.status === 200) {
        return res.data;
    }
    throw new Error("Network response not ok");
};


/***/ }),

/***/ 8887:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ QueueComp)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1775);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4178);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_7__]);
_pages_app__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const QueueComp = ()=>{
    const { data: session } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (!session) {
            next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/auth/signin");
        }
    }, []);
    const { song, setCurrentSong, user, openQueue, setopenQueue } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_7__.AppContext);
    const { data, isLoading, isError, error } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        openQueue
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .fetchQueueData */ .vy)(user?.id || "test"), {
        keepPreviousData: true,
        refetchOnMount: false,
        refetchOnWindowFocus: false
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Drawer, {
        anchor: "right",
        open: openQueue,
        onClose: ()=>setopenQueue(false),
        PaperProps: {
            sx: {
                background: "#22232d",
                width: 400,
                pl: 1,
                pr: 1
            }
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
            sx: {
                overflowY: "scroll"
            },
            children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CircularProgress, {
                size: 20
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                        variant: "body2",
                        sx: {
                            marginTop: 5,
                            pl: 2
                        },
                        children: "Now Playing"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.List, {
                        sx: {
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItem, {
                                sx: {
                                    backgroundColor: "#0093E9",
                                    backgroundImage: "linear-gradient(160deg, #0093E9 0%, #80D0C7 100%)",
                                    padding: 2
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                    container: true,
                                    spacing: 3,
                                    flexWrap: "nowrap",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                            item: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                src: "/sample.jpg",
                                                alt: "Picture of the author",
                                                width: 50,
                                                height: 50
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                            item: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    variant: "caption",
                                                    children: song?.name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    variant: "caption",
                                                    children: song?.artists?.map((x)=>x.title).toString()
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                variant: "subtitle2",
                                sx: {
                                    pt: 2
                                },
                                children: "Up Next"
                            }),
                            data?.map((song, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItem, {
                                    onClick: ()=>setCurrentSong(song),
                                    className: "playlist_song",
                                    sx: {
                                        "&:hover": {
                                            backgroundColor: "#0093E9"
                                        },
                                        p: 2
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                        container: true,
                                        spacing: 3,
                                        flexWrap: "nowrap",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                item: true,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                    src: song.thumbnail && song.thumbnail !== "no-cover.jpg" ? song.thumbnail : "/sample.jpg",
                                                    alt: "Picture of the author",
                                                    width: 60,
                                                    height: 60
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                item: true,
                                                display: "flex",
                                                flexDirection: "column",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                        sx: {
                                                            fontSize: "small"
                                                        },
                                                        children: [
                                                            song.name,
                                                            "  ",
                                                            song.duration
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                        sx: {
                                                            fontSize: "x-small",
                                                            color: "whitesmoke"
                                                        },
                                                        mt: 1,
                                                        children: [
                                                            "Album ",
                                                            song?.album
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, "playlist-song-" + index))
                        ]
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2401:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: () => (/* binding */ Songcomponent)
/* harmony export */ });
/* unused harmony export MediaType */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8924);
/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_player__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3866);
/* harmony import */ var _mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(340);
/* harmony import */ var _mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4178);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1775);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _hooks_windowDimensio__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3988);
/* harmony import */ var _player_CoverImage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5992);
/* harmony import */ var _player_Buttons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5284);
/* harmony import */ var _player_SeekBar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2545);
/* harmony import */ var _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8942);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1279);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_7__, _player_SeekBar__WEBPACK_IMPORTED_MODULE_14__, _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_15__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_7__, _player_SeekBar__WEBPACK_IMPORTED_MODULE_14__, _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















var MediaType;
(function(MediaType) {
    MediaType["song"] = "song";
    MediaType["radio"] = "radio";
    MediaType["podcast"] = "podcast";
})(MediaType || (MediaType = {}));
function Comp(props) {
    const { height, width } = (0,_hooks_windowDimensio__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const isMobile = width < 600 ? true : false;
    const { song, user, setCurrentSong, station, stations, setStation, setPodcast, podcast, podcastEpisodes, bgColor, setopenQueue, setUser } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_7__.AppContext);
    const [playing, setPlaying] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [currentMediaType, setCurrentMediaType] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const [streamLink, setStreamLink] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [showSpinner, setShowSpinner] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [progress, setupdateProgress] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [buffered, setBuffered] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [duration, setDuration] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [playBackError, setPlayBackError] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_10__.useQueryClient)();
    const playerRef = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createRef();
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (user && song) {
            (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .getStreamLink */ .Jh)(song.s3link, user.id || "test", song.id).then((res)=>{
                console.log("calling api", song.s3link, "res=", res);
                setCurrentMediaType(MediaType.song);
                if (res) {
                    setStreamLink(res);
                    setPlaying(true);
                }
            });
        }
    }, [
        song
    ]);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (user && !song) {
            (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .getNextQueueItem */ .$m)(user.id).then((song)=>{
                setCurrentSong(song.song);
                queryClient.setQueryData([
                    "queue",
                    user.id
                ], song.updated_queue);
            });
        }
    }, []);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        //add to user played tracks
        if (user && station) {
            setCurrentMediaType(MediaType.radio);
            (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .userListenedStation */ .bt)(user?.id, station?.id, 0);
            setPlaying(true);
        }
    }, [
        station
    ]);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        //add to user played tracks
        if (user && podcast) {
            setCurrentMediaType(MediaType.podcast);
            setPlaying(true);
        // userListenedStation(user?.id, station?.id, 0)
        }
    }, [
        podcast
    ]);
    const navigateToPlaylist = ()=>{
        next_router__WEBPACK_IMPORTED_MODULE_8___default().push({
            pathname: "/queue"
        }, undefined, {
            shallow: true
        });
    };
    const updateWithNewSong = async (userid)=>{
        const next_song = await (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .getNextQueueItem */ .$m)(userid);
        setCurrentSong(next_song.song);
        queryClient.setQueryData([
            "queue",
            userid
        ], next_song.updated_queue);
        return next_song.song.preview_url;
    };
    const onSongEnded = async ()=>{
        //fetch from queue and setSong
        if (!user) return;
        try {
            const preview_url = await updateWithNewSong(user.id);
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
            if (song) setCurrentSong(song);
        }
    };
    const playNextSong = async ()=>{
        //fetch from queue and setSong
        if (!user) return;
        try {
            const preview_url = await updateWithNewSong(user.id);
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
            if (song) setCurrentSong(song);
        }
    };
    const playPrevSong = async ()=>{
        //fetch from queue and setSong
        if (!user) return;
        try {
            const next_song = await (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .getPrevQueueItem */ .FG)(user.id);
            setCurrentSong(next_song.song);
            queryClient.setQueryData([
                "queue",
                user.id
            ], next_song.updated_queue);
        //remove from user
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
            if (song) setCurrentSong(song);
        }
    };
    const playNextRadioStation = async ()=>{
        //fetch from queue and setSong
        if (!stations?.length || !station) return;
        try {
            const currentStationIndex = stations?.findIndex((x)=>x.id == station.id);
            let next_st = stations[0];
            if (currentStationIndex != -1) {
                if (currentStationIndex == stations.length) next_st = stations[0];
                else next_st = stations[currentStationIndex + 1];
            }
            setStation(next_st);
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
        }
    };
    const playPrevRadioStation = async ()=>{
        //fetch from queue and setSong
        if (!stations?.length || !station) return;
        try {
            const currentStationIndex = stations?.findIndex((x)=>x.id == station.id);
            let prev_st = stations[0];
            if (currentStationIndex != -1) {
                if (currentStationIndex == 0) prev_st = stations[stations.length - 1];
                else prev_st = stations[currentStationIndex - 1];
            }
            setStation(prev_st);
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
        }
    };
    const playNextPodcast = async ()=>{
        //fetch from queue and setSong
        if (!podcastEpisodes?.length || !podcast) return;
        try {
            const currentStationIndex = podcastEpisodes?.findIndex((x)=>x.uuid == podcast.episode?.uuid);
            let next_st = podcastEpisodes[0];
            if (currentStationIndex != -1) {
                if (currentStationIndex == podcastEpisodes.length) next_st = podcastEpisodes[0];
                else next_st = podcastEpisodes[currentStationIndex + 1];
            }
            setPodcast({
                episode: next_st,
                podcast: podcast.podcast
            });
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
        }
    };
    function handleNext() {
        if (currentMediaType == "song") playNextSong();
        if (currentMediaType == "radio") playNextRadioStation();
        if (currentMediaType == "podcast") playNextPodcast();
    }
    const playPrevPodcast = async ()=>{
        //fetch from queue and setSong
        if (!podcastEpisodes?.length || !podcast) return;
        try {
            const currentStationIndex = podcastEpisodes?.findIndex((x)=>x.uuid == podcast.episode?.uuid);
            let prev_st = podcastEpisodes[0];
            if (currentStationIndex != -1) {
                if (currentStationIndex == 0) prev_st = podcastEpisodes[podcastEpisodes.length - 1];
                else prev_st = podcastEpisodes[currentStationIndex - 1];
            }
            setPodcast({
                episode: prev_st,
                podcast: podcast.podcast
            });
        } catch (error) {
            console.error("Error in getting next item playing the same song again");
        }
    };
    function handlePrev() {
        station ? playPrevRadioStation() : podcast ? playPrevPodcast() : playPrevSong();
    }
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const requestTrack = async ()=>{
        if (!user || !song) return null;
        await (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .requestTrackAddition */ .hH)(user.id, song?.id);
    };
    const updateProgress = async (event)=>{
        if (playBackError) {
            setPlayBackError(undefined);
        // handleNext()
        }
        setBuffered(event.loadedSeconds);
        setupdateProgress(event.playedSeconds);
        //todo track 
        if (event.playedSeconds % 30 == 0) {
            if (currentMediaType == "podcast") {
                await (0,_api__WEBPACK_IMPORTED_MODULE_9__/* .userListenedPodcasts */ .S9)(user?.id, podcast?.podcast.uuid, event.playedSeconds, podcast?.episode?.uuid);
            }
        }
    };
    const signature = streamLink ? new URL(streamLink).searchParams.get("Signature") : "";
    const policy = streamLink ? new URL(streamLink).searchParams.get("Policy") : "";
    // console.log("streamLink && currentMediaType", streamLink, currentMediaType)
    async function likeSong() {
        if (song) saveToLikedSongs.mutate({
            songid: song.id,
            likedislike: (0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedSong */ .Xg)(user, song.id)
        });
    }
    const saveToLikedSongs = (0,react_query__WEBPACK_IMPORTED_MODULE_10__.useMutation)(({ songid, likedislike })=>(0,_api__WEBPACK_IMPORTED_MODULE_9__/* .liekdislikesong */ .gH)(user?.id || "1", likedislike, songid), {
        onSuccess: (data)=>{
            queryClient.setQueryData([
                "user",
                {
                    id: user?.id
                }
            ], data);
            setUser(data);
            console.log("OnSuccess", user?.id, data);
        }
    });
    const LoveTrack = ({ song })=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.NoSsr, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
                className: "song_player_comp",
                style: {
                    backgroundColor: "rgb(22 23 24)"
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    container: true,
                    className: "button_metadaga_container",
                    style: {
                        height: "100%",
                        minHeight: 63
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            sx: {
                                display: "flex",
                                alignItems: "center"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_player_CoverImage__WEBPACK_IMPORTED_MODULE_12__/* .CoverImg */ .O, {
                                    song: currentMediaType == "song" ? song : currentMediaType == "radio" ? station : currentMediaType == "podcast" ? podcast?.episode : song,
                                    currentMediaType: currentMediaType
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    item: true,
                                    sx: {
                                        textAlign: "center",
                                        width: "70%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_player_Buttons__WEBPACK_IMPORTED_MODULE_13__/* .Buttons */ .E, {
                                        playing: playing,
                                        handlePrev: handlePrev,
                                        handleNext: handleNext,
                                        setPlaying: setPlaying
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    display: "flex"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_player_SeekBar__WEBPACK_IMPORTED_MODULE_14__/* .SeekBar */ .W, {
                                        progress: progress,
                                        playBackError: playBackError,
                                        duration: duration,
                                        playerRef: playerRef,
                                        buffer: buffered
                                    }),
                                    streamLink && currentMediaType == "song" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_player__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        url: streamLink,
                                        controls: false,
                                        playing: playing,
                                        playsinline: true,
                                        height: "30px",
                                        width: "77vh%",
                                        ref: playerRef,
                                        forceAudio: true,
                                        style: {
                                            color: "white"
                                        },
                                        onPlay: ()=>setShowSpinner(false),
                                        onBuffer: ()=>setShowSpinner(true),
                                        config: {
                                            file: {
                                                forceHLS: true,
                                                hlsOptions: {
                                                    xhrSetup: function(xhr, url) {
                                                        if (url.indexOf("https://dpashj04akcoe.cloudfront.net/") === 0) {
                                                            if (url.slice(-2) == "ts") {
                                                                url += "?" + `Policy=${policy}&Key-Pair-Id=K3QOPS3KJYTLPK&Signature=${signature}`; // this suffix is updated every [x] seconds by polling the server
                                                                xhr.open("GET", url, true);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                        onEnded: onSongEnded,
                                        onProgress: updateProgress,
                                        onDuration: (e)=>setDuration(e),
                                        onError: (e)=>setPlayBackError(e)
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_player__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        url: currentMediaType == "radio" ? station?.url : currentMediaType == "song" ? song?.preview_url : currentMediaType == "podcast" ? podcast?.episode?.audio_url : "",
                                        controls: false,
                                        playing: playing,
                                        height: "30px",
                                        width: "77vh%",
                                        ref: playerRef,
                                        style: {
                                            color: "white"
                                        },
                                        onEnded: onSongEnded,
                                        onPlay: ()=>setShowSpinner(false),
                                        onBuffer: ()=>setShowSpinner(true),
                                        onProgress: updateProgress,
                                        onDuration: (e)=>setDuration(e)
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            sx: {
                                maxHeight: "8vh",
                                marginLeft: "5%"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                container: true,
                                columnGap: "5%",
                                alignItems: "center",
                                children: [
                                    !station ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                                        title: "Add to Playlist",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                            onClick: ()=>setOpen(true),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                fontSize: "medium",
                                                style: {
                                                    fill: "white"
                                                },
                                                className: "play-comp-icons"
                                            })
                                        })
                                    }) : "",
                                    !station ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                                        title: "Queue",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                            onClick: ()=>setopenQueue(true),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                fontSize: "medium",
                                                style: {
                                                    fill: "white"
                                                },
                                                className: "play-comp-icons"
                                            })
                                        })
                                    }) : "",
                                    song ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                                        title: "Fav",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: currentMediaType == "song" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                                onClick: ()=>saveToLikedSongs.mutate({
                                                        songid: song.id,
                                                        likedislike: (0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedSong */ .Xg)(user, song.id)
                                                    }),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    fontSize: "small",
                                                    className: !(0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedSong */ .Xg)(user, song.id) ? "user-liked-song" : "play-comp-icons"
                                                })
                                            }) : currentMediaType == "radio" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                                onClick: ()=>saveToLikedSongs.mutate({
                                                        songid: song.id,
                                                        likedislike: (0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedRadio */ .S7)(user, song.id)
                                                    }),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    fontSize: "small",
                                                    className: !(0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedRadio */ .S7)(user, song.id) ? "user-liked-song" : "play-comp-icons"
                                                })
                                            }) : currentMediaType == "podcast" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                                onClick: ()=>saveToLikedSongs.mutate({
                                                        songid: song.uuid,
                                                        likedislike: (0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedPodcast */ .ic)(user, song.uuid)
                                                    }),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    fontSize: "small",
                                                    className: !(0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .checkIfUserHasLikedPodcast */ .ic)(user, song.uuid) ? "user-liked-song" : "play-comp-icons"
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                        })
                                    }) : ""
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_15__/* .UserPlayLists */ .y, {
                    open: open,
                    setOpen: setOpen,
                    song: song
                })
            })
        ]
    });
}
const Songcomponent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.memo(Comp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ CreateNewPlayListModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9564);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Modal__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1775);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4178);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _SideBar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5755);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_8__, _SideBar__WEBPACK_IMPORTED_MODULE_10__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_8__, _SideBar__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











function CreateNewPlayListModal({ open, setOpen }) {
    const { user } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_8__.AppContext);
    const [name, setName] = react__WEBPACK_IMPORTED_MODULE_1__.useState();
    const [image, setImage] = react__WEBPACK_IMPORTED_MODULE_1__.useState({
        preview: "",
        data: ""
    });
    const [status, setStatus] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [Imgopen, setImgOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: _SideBar__WEBPACK_IMPORTED_MODULE_10__/* .editor_user_id */ .h == user?.id ? "60%" : "30%",
        height: _SideBar__WEBPACK_IMPORTED_MODULE_10__/* .editor_user_id */ .h == user?.id ? "41%" : "30%",
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        p: 2
    };
    const handleImgClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        setImgOpen(false);
    };
    // const handleSubmit = async (e) => {
    //     e.preventDefault()
    //     let formData = new FormData()
    //     formData.append('file', image.data)
    //     const response = await fetch('http://localhost:5000/image', {
    //         method: 'POST',
    //         body: formData,
    //     })
    //     if (response) setStatus(response.statusText)
    // }
    const handleFileChange = async (e)=>{
        const img = {
            preview: URL.createObjectURL(e.target.files[0]),
            data: e.target.files[0]
        };
        setImage(img);
        try {
            setImgOpen(true);
            setStatus("Image upload success");
        } catch (error) {
            setImgOpen(true);
            setStatus(`Image upload error ${JSON.stringify(error)}`);
            console.error("Error in adding playlist!!!!!", error);
        }
    };
    const handleChange = (event)=>{
        setName(event.target.value);
    };
    const [err, setErr] = react__WEBPACK_IMPORTED_MODULE_1__.useState();
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_9__.useQueryClient)();
    const handleClose = ()=>setOpen(false);
    const createNewPlayListHandler = async ()=>{
        try {
            if (!user) {
                setErr("Error in creating new playlist");
                return;
            }
            //@ts-ignore
            const filename = await (0,_api__WEBPACK_IMPORTED_MODULE_7__/* .uploadImage */ .Ix)(image.data);
            await (0,_api__WEBPACK_IMPORTED_MODULE_7__/* .createNewPlaylist */ .zQ)(user?.id, name || "", filename);
            await queryClient.invalidateQueries([
                "user",
                user.id
            ]);
            await queryClient.invalidateQueries([
                "user_playlist",
                user.id
            ]);
            setErr("");
            setOpen(false);
        } catch (error) {
            setErr("Error in creating new playlist");
        }
    };
    const bg = image.preview ? ` url(${image.preview})` : "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Modal__WEBPACK_IMPORTED_MODULE_5___default()), {
                open: open,
                onClose: handleClose,
                "aria-labelledby": "modal-modal-title",
                "aria-describedby": "modal-modal-description",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                    sx: {
                        ...style,
                        backgroundImage: bg,
                        backgroundSize: "cover"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                            id: "modal-modal-title",
                            variant: "caption",
                            component: "h2",
                            sx: {
                                color: "whitesmoke"
                            },
                            children: "Add New Playlist"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                            sx: {
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "space-between",
                                height: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.TextField, {
                                    id: "outlined-name",
                                    label: "your playlist name",
                                    value: name,
                                    onChange: handleChange,
                                    sx: {
                                        mt: 2
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "file-input",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "file",
                                            id: "file",
                                            className: "file",
                                            onChange: handleFileChange
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "file",
                                            children: "Select file"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    color: "secondary",
                                    sx: {
                                        color: "white",
                                        maxWidth: 100
                                    },
                                    size: "small",
                                    variant: "contained",
                                    onClick: createNewPlayListHandler,
                                    children: "Add"
                                }),
                                err && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    children: "Something went wrong please try again.."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Snackbar, {
                anchorOrigin: {
                    vertical: "top",
                    horizontal: "right"
                },
                open: Imgopen,
                onClose: handleImgClose,
                message: status
            }, "snackbar")
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5755:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: () => (/* binding */ SideBar),
/* harmony export */   h: () => (/* binding */ editor_user_id)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1883);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(340);
/* harmony import */ var _mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_HomeMax__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1659);
/* harmony import */ var _mui_icons_material_HomeMax__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HomeMax__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Addchart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2321);
/* harmony import */ var _mui_icons_material_Addchart__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Addchart__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Radio__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3526);
/* harmony import */ var _mui_icons_material_Radio__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Radio__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Podcasts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(907);
/* harmony import */ var _mui_icons_material_Podcasts__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Podcasts__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_TrackChanges__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9044);
/* harmony import */ var _mui_icons_material_TrackChanges__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_TrackChanges__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _CreateNewPlayList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2405);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1775);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4178);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CreateNewPlayList__WEBPACK_IMPORTED_MODULE_14__, _pages_app__WEBPACK_IMPORTED_MODULE_18__]);
([_CreateNewPlayList__WEBPACK_IMPORTED_MODULE_14__, _pages_app__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const drawerWidth = 180;
const editor_user_id = "038f20a8-6454-482f-9fec-1473c33f74b1";
function SideBarComp(props) {
    const { setSearchTerm, user, bgColor } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_18__.AppContext);
    const [mobileOpen, setMobileOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_17__.useQueryClient)();
    // const handleDrawerToggle = (value?: boolean) => {
    //     if (value) setMobileOpen(value)
    //     setMobileOpen(!mobileOpen);
    // };
    let menuitems = [
        {
            name: "Home",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_HomeMax__WEBPACK_IMPORTED_MODULE_5___default()), {}),
            path: "/"
        },
        {
            name: "Search",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_12___default()), {}),
            path: "/search"
        },
        // { name: 'Albums', icon: <LibraryMusic />, path: '/playlist'
        // }, { name: 'Artists', icon: <AccountCircle />, path: '/artist' },
        // { name: 'PlayLists Collections', icon: <PlaylistPlay />, path: '/playlist_collection' },
        {
            name: "Radio",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Radio__WEBPACK_IMPORTED_MODULE_8___default()), {}),
            path: "/radio"
        },
        {
            name: "Podcasts",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Podcasts__WEBPACK_IMPORTED_MODULE_9___default()), {}),
            path: "/podcast"
        },
        // { name: 'Upload Songs', icon: <AccountCircle />, path: '/upload' },
        {
            name: "Ready to Stream",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_TrackChanges__WEBPACK_IMPORTED_MODULE_10___default()), {}),
            path: "/available_tracks"
        }
    ];
    editor_user_id == user?.id && menuitems.push({
        name: "Upload Songs",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_3___default()), {}),
        path: "/upload"
    });
    const createNewPlayList = ()=>{
        setOpen(true);
    };
    const deletePlayListHandler = async (playlistid)=>{
        if (!user?.id) return;
        await (0,_api__WEBPACK_IMPORTED_MODULE_16__/* .deletePlayList */ .jV)(user.id, playlistid);
        await queryClient.invalidateQueries([
            "user",
            user.id
        ]);
        await queryClient.invalidateQueries([
            "user_playlist",
            user.id
        ]);
        await queryClient.invalidateQueries([
            "playlist",
            playlistid
        ]);
        console.log("Delete", user.name);
    };
    const { data } = (0,react_query__WEBPACK_IMPORTED_MODULE_17__.useQuery)([
        "user",
        user?.id
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_16__/* .fetchUserData */ .FQ)(user?.name));
    let playlistitems = data?.playlists?.map((x)=>({
            id: x.id,
            name: x.name,
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_QueueMusic__WEBPACK_IMPORTED_MODULE_4___default()), {}),
            path: `/playlist/${x.id}`
        })) || [];
    playlistitems = [
        {
            id: "liked_xsongs",
            name: "Your Fav Songs",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_11___default()), {}),
            path: `/fav`
        },
        ...playlistitems
    ];
    const styles = {};
    const drawer = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "drawesidebar",
        style: {
            height: "100%",
            overflowY: "hidden",
            ...styles
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: menuitems.map((x, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_13___default()), {
                        href: x.path,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Box, {
                            sx: {
                                display: "flex",
                                columnGap: 1,
                                alignItems: "center"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Icon, {
                                    sx: {
                                        minWidth: 27
                                    },
                                    fontSize: "small",
                                    children: x.icon
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Typography, {
                                    className: "sidebar-listItemText",
                                    sx: {
                                        lineHeight: 1,
                                        margin: 0,
                                        fontSize: "small"
                                    },
                                    children: x.name
                                })
                            ]
                        })
                    }, "menu" + index))
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_List__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    display: "flex",
                    justifyContent: "space-around",
                    alignItems: "center"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Typography, {
                        sx: {
                            "&:hover": {
                                backgroundColor: "white",
                                color: "black",
                                cursor: "pointer"
                            }
                        },
                        children: "PlayList"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.IconButton, {
                        "aria-label": "createnewplaylist",
                        onClick: createNewPlayList,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Tooltip, {
                            title: "Create new Playlist",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Addchart__WEBPACK_IMPORTED_MODULE_6___default()), {
                                fontSize: "large",
                                sx: {
                                    fontSize: "1.5rem !important"
                                }
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    overflowY: "scroll",
                    height: 300
                },
                children: playlistitems.map((x, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_13___default()), {
                        href: x.path,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Box, {
                            display: "flex",
                            sx: {
                                alignItems: "center",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Box, {
                                    display: "flex",
                                    sx: {
                                        alignItems: "center",
                                        flex: 2,
                                        columnGap: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Icon, {
                                            sx: {
                                                minWidth: 27
                                            },
                                            fontSize: "small",
                                            children: x.icon
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Typography, {
                                            style: {
                                                fontSize: "small"
                                            },
                                            children: x.name
                                        })
                                    ]
                                }),
                                x.id !== "liked_songs" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.IconButton, {
                                    onClick: ()=>deletePlayListHandler(x.id),
                                    sx: {
                                        minWidth: 27,
                                        flex: 0.1
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        fontSize: "small"
                                    })
                                })
                            ]
                        })
                    }, "libraryitems" + index))
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            drawer,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CreateNewPlayList__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                open: open,
                setOpen: setOpen
            })
        ]
    });
}
function moviePropsAreEqual(prevProps, nextProps) {
    return prevProps === nextProps;
}
const SideBar = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.memo(SideBarComp, moviePropsAreEqual);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8942:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   y: () => (/* binding */ UserPlayLists)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1775);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4178);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_5__]);
_pages_app__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 2
};
const UserPlayLists = ({ open, setOpen, song })=>{
    if (!song) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    const { user } = react__WEBPACK_IMPORTED_MODULE_2__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_5__.AppContext);
    const [err, setErr] = react__WEBPACK_IMPORTED_MODULE_2__.useState();
    const [checked, setChecked] = react__WEBPACK_IMPORTED_MODULE_2__.useState();
    const { data, isLoading, isError, error } = (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)([
        "user_playlist",
        user?.id
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_4__/* .getUserPlaylist */ .N3)(user?.id), {
        keepPreviousData: false,
        refetchOnMount: true,
        refetchOnWindowFocus: true
    });
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useQueryClient)();
    const handleClose = ()=>{
        setOpen(false);
        setErr("");
        setChecked([]);
    };
    const handleCheckBOxChange = (event, selectedid)=>{
        let newChecked = checked || [];
        if (!data?.length) return;
        if (checked?.includes(selectedid)) {
            //already in user's playlist
            if (!event.currentTarget.checked) {
                //nchecked
                newChecked = newChecked.filter((x)=>x !== selectedid);
            } else {
            //do nothing
            }
        } else {
            //user has added to his checklist
            newChecked.push(selectedid);
        }
        setChecked(newChecked);
    };
    react__WEBPACK_IMPORTED_MODULE_2__.useEffect(()=>{
        if (data?.length) {
            const presentinplcs = [];
            data.forEach((x)=>{
                if (x.tracks.includes(song.id)) {
                    presentinplcs.push(x.id);
                }
            });
            setChecked([
                ...presentinplcs
            ]);
        }
    }, [
        data?.length
    ]);
    const addtoplaylist = async ()=>{
        console.log("selectedPlayLists", checked);
        if (!user?.id || !checked?.length) return;
        await (0,_api__WEBPACK_IMPORTED_MODULE_4__/* .addSongToPlaylist */ .AP)(user.id, checked, song.id, song.thumbnail);
        for (const x of checked){
            console.log("invalidating playlist for", x);
            await queryClient.invalidateQueries([
                "playlist",
                x
            ]);
        }
        setOpen(false);
        console.log("Close called");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Modal, {
        open: open,
        onClose: handleClose,
        "aria-labelledby": "modal-modal-title",
        "aria-describedby": "modal-modal-description",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: style,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                    children: "Your PlayLists"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormGroup, {
                    children: data?.map((playlist, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                            control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Checkbox, {
                                checked: checked?.includes(playlist.id),
                                onChange: (e)=>handleCheckBOxChange(e, playlist.id)
                            }),
                            label: playlist.name,
                            sx: {
                                color: "white"
                            }
                        }, playlist.id))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                    color: "secondary",
                    onClick: addtoplaylist,
                    sx: {
                        mt: 2
                    },
                    children: "Add To Playlist"
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Buttons)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_icons_material_FastRewindRounded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1650);
/* harmony import */ var _mui_icons_material_FastRewindRounded__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FastRewindRounded__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5766);
/* harmony import */ var _mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_PauseRounded__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6673);
/* harmony import */ var _mui_icons_material_PauseRounded__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PauseRounded__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_FastForwardRounded__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9670);
/* harmony import */ var _mui_icons_material_FastForwardRounded__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FastForwardRounded__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);






const Buttons = ({ playing, handlePrev, handleNext, setPlaying })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    const mainIconColor = theme.palette.mode === "dark" ? "#fff" : "#000";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
        sx: {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            mt: -1
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                "aria-label": "previous song",
                onClick: handlePrev,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FastRewindRounded__WEBPACK_IMPORTED_MODULE_1___default()), {
                    fontSize: "large",
                    htmlColor: mainIconColor
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                onClick: ()=>{
                    !playing ? setPlaying(true) : setPlaying(false);
                },
                "aria-label": !playing ? "play" : "pause",
                children: !playing ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2___default()), {
                    sx: {
                        fontSize: "3rem"
                    },
                    htmlColor: mainIconColor
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PauseRounded__WEBPACK_IMPORTED_MODULE_3___default()), {
                    sx: {
                        fontSize: "3rem"
                    },
                    htmlColor: mainIconColor
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                "aria-label": "next song",
                onClick: handleNext,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FastForwardRounded__WEBPACK_IMPORTED_MODULE_4___default()), {
                    fontSize: "large",
                    htmlColor: mainIconColor
                })
            })
        ]
    });
};


/***/ }),

/***/ 5992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ CoverImg)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);



const CoverImage = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)("div")({
    width: 100,
    height: 100,
    objectFit: "cover",
    overflow: "hidden",
    flexShrink: 0,
    borderRadius: 8,
    backgroundColor: "rgba(0,0,0,0.08)",
    "& > img": {
        width: "100%"
    }
});
const CoverImg = ({ song, currentMediaType })=>{
    let thumbnail = "";
    let title = "";
    let artists = "";
    let album = "";
    switch(currentMediaType){
        case "song":
            song = song;
            thumbnail = song?.thumbnail !== "no-cover.jpg" ? song?.thumbnail : "/sample.jpg";
            title = song?.name;
            artists = song?.artists?.map((x)=>x.title).join(" , ");
            album = song?.album?.title;
            break;
        case "radio":
            song = song;
            thumbnail = song?.favicon !== "no-cover.jpg" ? song?.favicon.startsWith("/") ? "https://pcradio.ru/" + song?.favicon : song?.favicon : "/sample.jpg";
            title = song?.name;
            break;
        case "podcast":
            song = song;
            thumbnail = song?.image_url ?? "/sample.jpg";
            title = song?.name;
            break;
        default:
            break;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            display: "flex",
            alignItems: "center"
        },
        children: [
            thumbnail && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                alt: "",
                src: thumbnail,
                height: 70,
                width: 100
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    ml: 1.5,
                    minWidth: 0,
                    display: "flex",
                    maxWidth: "206px",
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        variant: "caption",
                        fontSize: "x-small",
                        color: "white",
                        children: artists
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        fontSize: "x-small",
                        color: "white",
                        sx: {
                            textWrap: "balance"
                        },
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        noWrap: true,
                        letterSpacing: -0.25,
                        fontSize: "x-small",
                        variant: "caption",
                        color: "white",
                        children: album
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 2545:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ SeekBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4115);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_styled__WEBPACK_IMPORTED_MODULE_1__]);
_emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const TinyText = (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_1__["default"])(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography)({
    color: "white",
    fontSize: "0.75rem",
    // opacity: 0.38,
    fontWeight: 500
});
function formatDuration(value) {
    value = parseInt(value);
    const minute = Math.floor(value / 60);
    const secondLeft = value - minute * 60;
    return `${minute}:${secondLeft < 10 ? `0${secondLeft}` : secondLeft}`;
}
const SeekBar = ({ progress, duration, playerRef, buffer, playBackError })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            playBackError && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "caption",
                color: "red",
                children: [
                    "Something went wrong, please play other song.",
                    playBackError
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Slider, {
                "aria-label": "time-indicator",
                size: "small",
                value: progress,
                min: 0,
                step: 1,
                max: duration,
                onChange: (_, value)=>{
                    playerRef.current?.seekTo(value);
                },
                sx: {
                    color: "white",
                    height: 6,
                    "& .MuiSlider-thumb": {
                        width: 8,
                        height: 8,
                        transition: "0.3s cubic-bezier(.47,1.64,.41,.8)",
                        "&:before": {
                            boxShadow: "0 2px 12px 0 rgba(0,0,0,0.4)"
                        },
                        "&:hover, &.Mui-focusVisible": {
                            boxShadow: `0px 0px 0px 8px rgb(255 255 255 / 16%)`
                        },
                        "&.Mui-active": {
                            width: 20,
                            height: 20
                        }
                    },
                    "& .MuiSlider-rail": {
                        opacity: 0.28
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.LinearProgress, {
                    variant: "buffer",
                    value: progress,
                    valueBuffer: buffer
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    ml: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TinyText, {
                        children: formatDuration(progress)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TinyText, {
                        children: [
                            "/",
                            formatDuration(duration - progress)
                        ]
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ useWindowDimensions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function getWindowDimensions() {
    const { innerWidth: width, innerHeight: height } = window;
    return {
        width,
        height
    };
}
function useWindowDimensions() {
    const [windowDimensions, setWindowDimensions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getWindowDimensions());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        function handleResize() {
            setWindowDimensions(getWindowDimensions());
        }
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    return windowDimensions;
}


/***/ }),

/***/ 4178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppContext: () => (/* binding */ AppContext),
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1598);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_SongComponent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2401);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1775);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_common_SideBar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5755);
/* harmony import */ var react_query_devtools__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5918);
/* harmony import */ var react_query_devtools__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_query_devtools__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8942);
/* harmony import */ var _components_Queue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8887);
/* harmony import */ var _hooks_windowDimensio__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3988);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_SongComponent__WEBPACK_IMPORTED_MODULE_7__, _components_common_SideBar__WEBPACK_IMPORTED_MODULE_11__, _components_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_13__, _components_Queue__WEBPACK_IMPORTED_MODULE_14__]);
([_components_SongComponent__WEBPACK_IMPORTED_MODULE_7__, _components_common_SideBar__WEBPACK_IMPORTED_MODULE_11__, _components_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_13__, _components_Queue__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const darkTheme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.createTheme)({
    palette: {
        mode: "dark"
    }
});
const AppContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_3___default().createContext(null);
function App({ Component, pageProps: { session, ...pageProps } }) {
    let width = 1024;
    if (false) {}
    const [queryClient] = react__WEBPACK_IMPORTED_MODULE_3___default().useState(()=>new react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClient({
            defaultOptions: {
                queries: {
                    refetchOnWindowFocus: false,
                    keepPreviousData: true,
                    refetchOnMount: false,
                    cacheTime: 36000
                }
            }
        }));
    const initSettings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 6,
        initialSlide: 0
    };
    const [bgColor, setBgColor] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [carouseSettings, setCarouseSettings] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        ...initSettings,
        slidesToShow: 7,
        slidesToScroll: 7
    });
    const [song, setCurrentSong] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [songForAddToPlc, setsongForAddToPlc] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [station, setStation] = react__WEBPACK_IMPORTED_MODULE_3___default().useState();
    const [podcast, setPodcast] = react__WEBPACK_IMPORTED_MODULE_3___default().useState();
    const [stations, setStations] = react__WEBPACK_IMPORTED_MODULE_3___default().useState([]);
    const [stationForAddToPlc, setstationForAddToPlc] = react__WEBPACK_IMPORTED_MODULE_3___default().useState();
    const [podcastEpisodes, setPodcastEpisodes] = react__WEBPACK_IMPORTED_MODULE_3___default().useState([]);
    const [searchTerm, setSearchTerm] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [openSideBarMeu, toggleSideBarMenu] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [openQueue, setopenQueue] = react__WEBPACK_IMPORTED_MODULE_3___default().useState(false);
    const [mobileOpen, setMobileOpen] = react__WEBPACK_IMPORTED_MODULE_3___default().useState(false);
    const [openAddToPlayListMenu, setopenAddToPlayListMenu] = react__WEBPACK_IMPORTED_MODULE_3___default().useState(false);
    const setSong = async (song)=>{
        if (user) await (0,_api__WEBPACK_IMPORTED_MODULE_8__/* .addToQueue */ .xd)(user.id, song.id);
        // console.log("setSong", song?.id)
        setCurrentSong(song);
    };
    const handleDrawerToggle = ()=>{
        setMobileOpen(!mobileOpen);
    };
    react__WEBPACK_IMPORTED_MODULE_3___default().useEffect(()=>{
        // console.log("window width changed", width)
        if (width < 600) {
            setCarouseSettings({
                ...initSettings,
                slidesToShow: 3,
                slidesToScroll: 3
            });
        }
        if (width < 1024 && width > 600) {
            setCarouseSettings({
                ...initSettings,
                slidesToShow: 4,
                slidesToScroll: 4
            });
        }
        if (width >= 1024) {
            setCarouseSettings({
                ...initSettings,
                slidesToShow: 6,
                slidesToScroll: 6
            });
        }
    }, [
        width
    ]);
    // setInterval(() => {
    //   console.log("interval")
    //   // setBgColor(colorChanger())
    // }, 10000)
    if (true) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
    const drawerWidth = 180;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_10__.NoSsr, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_auth_react__WEBPACK_IMPORTED_MODULE_9__.SessionProvider, {
            session: session,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.ThemeProvider, {
                theme: darkTheme,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClientProvider, {
                    client: queryClient,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_query__WEBPACK_IMPORTED_MODULE_2__.Hydrate, {
                            state: pageProps.dehydratedState,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppContext.Provider, {
                                value: {
                                    bgColor,
                                    setBgColor,
                                    user,
                                    setUser,
                                    song,
                                    setCurrentSong: setSong,
                                    openSideBarMeu,
                                    toggleSideBarMenu,
                                    searchTerm,
                                    setSearchTerm,
                                    station,
                                    setStation,
                                    stations,
                                    setStations,
                                    podcast,
                                    setPodcast,
                                    podcastEpisodes,
                                    setPodcastEpisodes,
                                    openAddToPlayListMenu,
                                    setopenAddToPlayListMenu,
                                    songForAddToPlc,
                                    setsongForAddToPlc,
                                    openQueue,
                                    setopenQueue,
                                    carouseSettings,
                                    stationForAddToPlc,
                                    setstationForAddToPlc
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Auth, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Box, {
                                        sx: {},
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Box, {
                                                sx: {},
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Box, {
                                                        // component="nav"
                                                        sx: {
                                                            display: "flex",
                                                            width: {
                                                                sm: drawerWidth
                                                            },
                                                            flexShrink: {
                                                                sm: 0
                                                            },
                                                            overflowY: "scroll"
                                                        },
                                                        "aria-label": "mailbox folders",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Drawer, {
                                                                // container={container}
                                                                variant: "temporary",
                                                                open: mobileOpen,
                                                                onClose: handleDrawerToggle,
                                                                ModalProps: {
                                                                    keepMounted: true
                                                                },
                                                                sx: {
                                                                    ...bgColor,
                                                                    display: {
                                                                        xs: "block",
                                                                        sm: "none"
                                                                    },
                                                                    "& .MuiDrawer-paper": {
                                                                        boxSizing: "border-box",
                                                                        width: drawerWidth + 50
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SideBar__WEBPACK_IMPORTED_MODULE_11__/* .SideBar */ .K, {
                                                                    user: user
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Drawer, {
                                                                variant: "permanent",
                                                                sx: {
                                                                    ...bgColor,
                                                                    display: {
                                                                        xs: "none",
                                                                        sm: "block"
                                                                    },
                                                                    "& .MuiDrawer-paper": {
                                                                        boxSizing: "border-box",
                                                                        width: drawerWidth,
                                                                        height: "89%",
                                                                        zIndex: 2
                                                                    }
                                                                },
                                                                open: true,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SideBar__WEBPACK_IMPORTED_MODULE_11__/* .SideBar */ .K, {
                                                                    user: user
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Box, {
                                                        component: "main",
                                                        mt: 1,
                                                        sx: {
                                                            marginLeft: {
                                                                md: `${drawerWidth}px`,
                                                                sm: 0
                                                            },
                                                            width: {
                                                                md: `calc(100% - ${drawerWidth}px)`,
                                                                sm: "100%"
                                                            },
                                                            padding: "0px 8px",
                                                            height: "90vh",
                                                            display: "flex",
                                                            flexDirection: "column",
                                                            background: "black !important",
                                                            color: "white",
                                                            overflowX: "hidden"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                                ...pageProps
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_13__/* .UserPlayLists */ .y, {
                                                                open: openAddToPlayListMenu,
                                                                setOpen: setopenAddToPlayListMenu,
                                                                song: songForAddToPlc
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SongComponent__WEBPACK_IMPORTED_MODULE_7__/* .Songcomponent */ .f, {
                                                drawerWidth: drawerWidth
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Queue__WEBPACK_IMPORTED_MODULE_14__/* .QueueComp */ .j, {})
                                        ]
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_query_devtools__WEBPACK_IMPORTED_MODULE_12__.ReactQueryDevtools, {
                            initialIsOpen: false
                        })
                    ]
                })
            })
        })
    });
}
function Auth({ children }) {
    const { data: session, status } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)({
        required: true
    });
    const isUser = !!session?.user;
    const { setUser, user } = react__WEBPACK_IMPORTED_MODULE_3___default().useContext(AppContext);
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQueryClient)();
    react__WEBPACK_IMPORTED_MODULE_3___default().useEffect(()=>{
        if (status === "loading") {
            // console.log("LOding now///")
            return;
        } // Do nothing while loading
        if (!isUser) {
            // console.log("redirecting to singni now///")
            (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.signIn)();
        }
    }, [
        isUser,
        status
    ]);
    if (isUser && !user && session?.user?.id) {
        // console.log('useroresent', session)
        (0,_api__WEBPACK_IMPORTED_MODULE_8__/* .fetchUserData */ .FQ)(session.user.id).then((data)=>{
            queryClient.setQueryData([
                "user",
                data.id
            ], data);
            setUser(data);
        }).catch((error)=>console.error(error));
        return children;
    }
    // Session is being fetched, or no user.
    // If no user, useEffect() will redirect.
    if (user) return children;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Loading..."
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Jn: () => (/* binding */ getImageUrl),
/* harmony export */   S7: () => (/* binding */ checkIfUserHasLikedRadio),
/* harmony export */   Xg: () => (/* binding */ checkIfUserHasLikedSong),
/* harmony export */   _B: () => (/* binding */ splitOnCaps),
/* harmony export */   av: () => (/* binding */ removeTags),
/* harmony export */   ic: () => (/* binding */ checkIfUserHasLikedPodcast),
/* harmony export */   ut: () => (/* binding */ millisToMinutesAndSeconds),
/* harmony export */   uw: () => (/* binding */ uniqueBy)
/* harmony export */ });
/* unused harmony exports numberWithCommas, capitalize, secondsToHm, secondsToMinutesAndSeconds, getchunks, colorChanger */
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function splitOnCaps(x) {
    const wordRegex = /[A-Z]?[a-z]+|[0-9]+|[A-Z]+(?![a-z])/g;
    const result = x.match(wordRegex)?.join(" ");
    return result;
}
function capitalize(x) {
    return x.charAt(0).toUpperCase() + x.slice(1);
}
function secondsToHm(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);
    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    // var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay;
}
function secondsToMinutesAndSeconds(d) {
    if (!d) return "";
    d = Number(d);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return m.toString().padStart(2, "0") + ":" + s.toString().padStart(2, "0");
}
function millisToMinutesAndSeconds(millis) {
    var minutes = Math.floor(millis / 60000);
    var seconds = (millis % 60000 / 1000).toFixed(0);
    return minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
}
function checkIfUserHasLikedSong(user, songid) {
    return Boolean(!user?.liked_songs?.includes(songid));
}
function checkIfUserHasLikedPodcast(user, songid) {
    return Boolean(!user?.liked_podcast?.includes(songid));
}
function checkIfUserHasLikedRadio(user, songid) {
    return Boolean(!user?.liked_radio?.includes(songid));
}
function getchunks(arr, len) {
    var chunks = [], i = 0, n = arr.length;
    while(i < n){
        const slicedata = arr.slice(i, i += len);
        chunks.push(slicedata);
    }
    return chunks;
}
function colorChanger() {
    const bgs = [
        {
            backgroundColor: "#0093E9",
            backgroundImage: "linear-gradient(160deg, #0093E9 0%, #80D0C7 100%)"
        },
        {
            backgroundColor: "#4158D0",
            backgroundImage: "linear-gradient(43deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%)"
        },
        {
            backgroundColor: "#FA8BFF",
            backgroundImage: "linear-gradient(45deg, #FA8BFF 0%, #2BD2FF 52%, #2BFF88 90%)"
        },
        {
            backgroundColor: "#FF9A8B",
            backgroundImage: "linear-gradient(90deg, #FF9A8B 0%, #FF6A88 55%, #FF99AC 100%)"
        },
        {
            // background: '#834d9b',  /* fallback for old browsers */
            background: "-webkit-linear-gradient(to right, #d04ed6, #834d9b)"
        }
    ];
    const idx = randomIntFromInterval(0, bgs.length);
    // console.log("color",bgs[idx])
    return bgs[idx];
}
function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}
const uniqueBy = (uniqueKey, objects)=>{
    const ids = objects.map((object)=>object[uniqueKey]);
    return objects.filter((object, index)=>!ids.includes(object[uniqueKey], index + 1));
};
function removeTags(str) {
    if (str === null || str === "") return false;
    else str = str?.toString();
    // Regular expression to identify HTML tags in
    // the input string. Replacing the identified
    // HTML tag with a null string.
    return str?.replace(/(<([^>]+)>)/ig, "");
}
function getImageUrl(url) {
    if (!url.includes("http") || !url.includes("https")) {
        return "/sample.jpg";
    }
    return url;
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ })

};
;