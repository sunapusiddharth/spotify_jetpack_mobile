"use strict";
exports.id = 812;
exports.ids = [812];
exports.modules = {

/***/ 9812:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4178);
/* harmony import */ var _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8942);
/* harmony import */ var _home_Card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8042);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_3__, _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_4__, _home_Card__WEBPACK_IMPORTED_MODULE_5__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_3__, _common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_4__, _home_Card__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const PlayListSongs = (props)=>{
    const { setCurrentSong } = react__WEBPACK_IMPORTED_MODULE_2__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_3__.AppContext);
    const handleSelectSong = (song)=>{
        // console.log("inside handleSelectSong")
        setCurrentSong(song);
    };
    const [addToPlayListSong, setaddToPlayListSong] = react__WEBPACK_IMPORTED_MODULE_2__.useState();
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_2__.useState(false);
    const hadleAddtoplaylist = (song)=>{
        // console.log("inside hadleAddtoplaylist")
        setaddToPlayListSong(song);
        setOpen(true);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                spacing: 2,
                container: true,
                mt: 4,
                children: props.data?.map((song, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        item: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_Card__WEBPACK_IMPORTED_MODULE_5__/* .ContentCard */ .u, {
                            data: {
                                image: song.thumbnail,
                                id: song.id,
                                title: song.name,
                                subtitle: "",
                                type: "music_card",
                                path: "",
                                song: song
                            }
                        })
                    }, "available_tracks" + song.id + index))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_UserPlayListModal__WEBPACK_IMPORTED_MODULE_4__/* .UserPlayLists */ .y, {
                open: open,
                setOpen: setOpen,
                song: addToPlayListSong
            })
        ]
    });
};
{}/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlayListSongs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;