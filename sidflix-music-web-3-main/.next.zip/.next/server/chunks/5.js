"use strict";
exports.id = 5;
exports.ids = [5];
exports.modules = {

/***/ 2005:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   y: () => (/* binding */ PlayList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1775);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1279);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_PlayCircleFilledRounded__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(247);
/* harmony import */ var _mui_icons_material_PlayCircleFilledRounded__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlayCircleFilledRounded__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _PlayListSongs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9812);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _PlayListSongs__WEBPACK_IMPORTED_MODULE_9__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _PlayListSongs__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function PlayListComp(props) {
    const { fav, data } = props;
    const { user, setCurrentSong } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_4__.AppContext);
    // const { data } = useQuery(["playlist", playlist], async () => { if (is_user_plc) { return await getFav(user?.id!) } else { return await fetchPlaylistData(playlist) } },);
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_5__.useQueryClient)();
    const playAllSongs = async ()=>{
        if (user && user.id && data) {
            await (0,_api__WEBPACK_IMPORTED_MODULE_6__/* .addPlayListToQueue */ .XM)(user.id, data.songs.map((x)=>x.id));
            await queryClient.refetchQueries([
                "queue",
                user.id
            ]);
            setCurrentSong(data.songs[0]);
            await queryClient.refetchQueries([
                "user",
                user.id
            ]);
        } else {
            console.error("No Error is found");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        mt: 4,
        children: [
            !fav ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                container: true,
                alignItems: "center",
                columnGap: 4,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        width: 450,
                        height: 300,
                        sx: {
                            background: "black"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                            alt: "",
                            src: data?.image && data.image !== "no-cover.jpg" ? data?.image : "/cover.jpg",
                            layout: "intrinsic",
                            width: 450,
                            height: 300
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                fontSize: "large",
                                children: data?.title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                fontSize: "medium",
                                children: [
                                    data?.artists.slice(0, 4).map((x)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            href: `artist/${x.id}`,
                                            children: x.name + "  "
                                        }, "artist" + x.id)),
                                    " ",
                                    data?.artists?.length > 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "and more"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                fontSize: "medium",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Chip, {
                                        label: data?.songs.length + " songs"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Chip, {
                                        label: (0,_utils__WEBPACK_IMPORTED_MODULE_11__/* .millisToMinutesAndSeconds */ .ut)(data?.songs.reduce((acc, x)=>acc += x.duration, 0) || 0) + " mins"
                                    }),
                                    "   "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                container: true,
                                columnGap: 4,
                                sx: {
                                    marginTop: 5,
                                    padding: 1
                                },
                                alignItems: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    item: true,
                                    display: "flex",
                                    flexDirection: "column",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
                                        title: "play all",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                            sx: {
                                                display: "flex",
                                                flexDirection: "row",
                                                alignItems: "center",
                                                columnGap: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlayCircleFilledRounded__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                    fontSize: "large",
                                                    onClick: playAllSongs,
                                                    sx: {
                                                        cursor: "pointer"
                                                    },
                                                    className: "play-all-songs"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    children: "Play All"
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                fontSize: "large",
                sx: {
                    margin: 3
                },
                textTransform: "uppercase",
                children: data?.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PlayListSongs__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                data: data?.songs || []
            })
        ]
    });
}
function moviePropsAreEqual(prevProps, nextProps) {
    ////console.log("Sidhu",prevProps,nextProps);
    return prevProps === nextProps;
}
const PlayList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.memo(PlayListComp, moviePropsAreEqual);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;