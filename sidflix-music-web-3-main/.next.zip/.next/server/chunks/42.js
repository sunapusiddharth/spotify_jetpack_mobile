"use strict";
exports.id = 42;
exports.ids = [42];
exports.modules = {

/***/ 4488:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ ContextMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8125);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1775);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1279);
/* harmony import */ var _mui_icons_material_BrokenImage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9516);
/* harmony import */ var _mui_icons_material_BrokenImage__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_BrokenImage__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_DeleteForever__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4334);
/* harmony import */ var _mui_icons_material_DeleteForever__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteForever__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_PlayCircle__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8618);
/* harmony import */ var _mui_icons_material_PlayCircle__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlayCircle__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3866);
/* harmony import */ var _mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_RequestPage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3266);
/* harmony import */ var _mui_icons_material_RequestPage__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_RequestPage__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _SideBar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5755);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _SideBar__WEBPACK_IMPORTED_MODULE_14__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _SideBar__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















function ContextMenu({ children, song, songId }) {
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_7__.useQueryClient)();
    const [contextMenu, setContextMenu] = react__WEBPACK_IMPORTED_MODULE_1__.useState(null);
    const [openSnack, setopenSnack] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [message, setMessage] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const { user, setCurrentSong, setsongForAddToPlc, setopenAddToPlayListMenu, setUser } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_4__.AppContext);
    const handleContextMenu = (event)=>{
        event.preventDefault();
        setContextMenu(contextMenu === null ? {
            mouseX: event.clientX + 2,
            mouseY: event.clientY - 6
        } : // Other native context menus might behave different.
        // With this behavior we prevent contextmenu from the backdrop to re-locale existing context menus.
        null);
    };
    const handleClose = (message)=>{
        setContextMenu(null);
        if (message) {
            setMessage(message);
            setopenSnack(true);
        }
    };
    function playSong() {
        if (song) setCurrentSong(song);
        handleClose();
    }
    const hadleAddtoplaylist = ()=>{
        if (song) {
            setsongForAddToPlc(song);
            setopenAddToPlayListMenu(true);
        }
        handleClose();
    };
    async function reportLink() {
        if (song) {
            await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .markAsBadLink */ .Vg)(song.id, true);
            handleClose("Sorry for your inconvenience, Song Reported As Not Playable.We will rectify as soon as possible.For contributing by uploading song by yourself please contact us at sunapusiddharth3@gmail.com. Thanks!!!");
        }
    }
    async function requestTrack() {
        if (song) {
            await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .requestTrackAddition */ .hH)(user?.id, song.id);
            handleClose("Track has been requested, will be added in few hours. For contributing by uploading song by yourself please contact us at sunapusiddharth3@gmail.com. Thanks!!!");
        }
    }
    async function likeSong() {
        if (song) {
            await saveToLikedSongs.mutate({
                songid: song.id,
                likedislike: (0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .checkIfUserHasLikedSong */ .Xg)(user, song.id)
            });
            handleClose("Added to Favourite");
        }
    }
    const saveToLikedSongs = (0,react_query__WEBPACK_IMPORTED_MODULE_7__.useMutation)(({ songid, likedislike })=>(0,_api__WEBPACK_IMPORTED_MODULE_5__/* .liekdislikesong */ .gH)(user?.id || "1", likedislike, songid), {
        onSuccess: (data)=>{
            queryClient.setQueryData([
                "user",
                {
                    id: user?.id
                }
            ], data);
            setUser(data);
            console.log("OnSuccess", user?.id, data);
        }
    });
    async function deleteSongFunc() {
        if (song) {
            await deleteSongFn.mutate({
                songid: song.id
            });
            handleClose("Song Deleted");
        }
    }
    const deleteSongFn = (0,react_query__WEBPACK_IMPORTED_MODULE_7__.useMutation)(({ songid })=>(0,_api__WEBPACK_IMPORTED_MODULE_5__/* .deleteSong */ .Sk)(songid), {
        onSuccess: (data)=>{
            const res = queryClient.getQueryData([
                "getAllAvailableSongs"
            ]);
            if (!res) return undefined;
            const newPagesArray = res?.pages.map((page)=>{
                const idx = page.results.findIndex((x)=>x.id == songId);
                if (idx !== -1) {
                    delete page.results[idx];
                }
                return page;
            });
            queryClient.setQueryData("getAllAvailableSongs", {
                pages: newPagesArray,
                pageParams: res.pageParams
            });
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onContextMenu: handleContextMenu,
        style: {
            cursor: "context-menu"
        },
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    height: "326px"
                },
                open: contextMenu !== null,
                onClose: ()=>handleClose(),
                anchorReference: "anchorPosition",
                anchorPosition: contextMenu !== null ? {
                    top: contextMenu.mouseY,
                    left: contextMenu.mouseX
                } : undefined,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: likeSong,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_10___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Add To Fav"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: playSong,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlayCircle__WEBPACK_IMPORTED_MODULE_11___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Play"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: hadleAddtoplaylist,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_12___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Add To Playlist"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: reportLink,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_BrokenImage__WEBPACK_IMPORTED_MODULE_8___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Link Not Working"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: requestTrack,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_RequestPage__WEBPACK_IMPORTED_MODULE_13___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Request Song"
                        ]
                    }),
                    user?.id == _SideBar__WEBPACK_IMPORTED_MODULE_14__/* .editor_user_id */ .h ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: deleteSongFunc,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DeleteForever__WEBPACK_IMPORTED_MODULE_9___default()), {
                                sx: {
                                    marginRight: 2
                                }
                            }),
                            " Delete"
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Snackbar, {
                anchorOrigin: {
                    vertical: "top",
                    horizontal: "right"
                },
                open: openSnack,
                onClose: ()=>setopenSnack(false),
                message: message,
                autoHideDuration: 1500
            }, "snackbar")
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8042:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ ContentCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4178);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _common_ConTextMenu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4488);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1279);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_5__, _common_ConTextMenu__WEBPACK_IMPORTED_MODULE_7__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_5__, _common_ConTextMenu__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function CardComp(props) {
    const { setCurrentSong, user } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_pages_app__WEBPACK_IMPORTED_MODULE_5__.AppContext);
    const { data } = props;
    const navigateToPlaylist = (path, type)=>{
        let basepath = "/playlist/";
        if (type == "playlist_collection_card") basepath = "/playlist_collection/";
        next_router__WEBPACK_IMPORTED_MODULE_8___default().push({
            pathname: basepath + path
        }, undefined, {
            shallow: true
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "img_container",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_ConTextMenu__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            song: data.song ?? undefined,
            songId: data.song?.id ?? undefined,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Card, {
                className: "home_carousel_card",
                sx: {
                    width: 180,
                    height: 240,
                    display: "flex",
                    flexDirection: "column",
                    alignContent: "center",
                    alignItems: "center",
                    justifyContent: " space-around",
                    "&:hover": {
                        cursor: "pointer"
                    },
                    background: "black"
                },
                onClick: ()=>data.type == "music_card" ? setCurrentSong(data.song) : navigateToPlaylist(data.id, data.type),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        alt: "",
                        src: data.image && data.image !== "no-cover.jpg" ? data.image : "/sample.jpg",
                        className: "imsage",
                        width: 180,
                        height: 220
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/play_icon.png",
                        className: "play_home"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/love.png",
                        className: !(0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .checkIfUserHasLikedSong */ .Xg)(user, data?.song?.id) ? "user-liked-song" : "user-neutral-song"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_2___default()), {
                        sx: {
                            fontSize: "small",
                            textAlign: "center",
                            padding: 0,
                            paddingBottom: "3px !important"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                                variant: "caption",
                                children: data.title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    data.subtitle,
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                style: {
                                    color: "darkgray",
                                    fontSize: "smaller"
                                },
                                children: [
                                    data.song?.artists?.map((x)=>x.title),
                                    " ",
                                    data.song?.album?.title && data.song?.album?.title !== "singles" ? " , " + data.song?.album?.title : ""
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                        ]
                    })
                ]
            })
        })
    });
}
function moviePropsAreEqual(prevProps, nextProps) {
    return prevProps === nextProps;
}
const ContentCard = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.memo(CardComp, moviePropsAreEqual);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;