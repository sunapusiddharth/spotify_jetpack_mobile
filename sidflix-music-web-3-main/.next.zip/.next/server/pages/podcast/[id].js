"use strict";
(() => {
var exports = {};
exports.id = 949;
exports.ids = [949,660];
exports.modules = {

/***/ 1046:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var next_dist_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2940);
/* harmony import */ var next_dist_pages_document__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_pages_document__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3718);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/podcast/[id]",
        pathname: "/podcast/[id]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: (next_dist_pages_document__WEBPACK_IMPORTED_MODULE_3___default())
    },
    userland: private_next_pages_podcast_id_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3718:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HoverableCard: () => (/* binding */ HoverableCard),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3534);
/* harmony import */ var _mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1775);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4178);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1279);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8792);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_app__WEBPACK_IMPORTED_MODULE_6__]);
_app__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const PodcastPage = ({})=>{
    const [openSnack, setopenSnack] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [message, setMessage] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const { data: session } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_8__.useSession)();
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (!session) {
            router.push("/auth/signin");
        }
    }, []);
    const { user, setPodcast } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_app__WEBPACK_IMPORTED_MODULE_6__.AppContext);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const queryClient = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQueryClient)();
    const [selectedSong, setSelectedSong] = react__WEBPACK_IMPORTED_MODULE_1__.useState();
    const [addedPodcast, setaddedPodcast] = react__WEBPACK_IMPORTED_MODULE_1__.useState();
    // const saveToLikedSongs = useMutation(({ songid, likedislike }: { songid: string, likedislike: boolean }) => liekdislikesong(user?.id || '1', likedislike, songid), {
    //     onSuccess: (data) => {
    //         queryClient.setQueryData(['user', { id: user?.id }], data)
    //         setUser(data)
    //         console.log("OnSuccess", user?.id, data)
    //     }
    // })
    async function playEpisode(song) {
        if (song && podcast) {
            setPodcast({
                episode: song,
                podcast
            });
            setaddedPodcast(song.uuid);
            await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .userListenedPodcasts */ .S9)(user?.id, podcast?.uuid, 0, song.uuid);
        }
    }
    function addToWatchLater() {
        if (selectedSong) {
        //make api call to save this data
        // setPodcast(selectedSong)
        }
    }
    const addToQueue = ()=>{};
    // const [addToPlayListSong, setaddToPlayListSong] = React.useState<SongType>();
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    // const hadleAddtoplaylist = (song: SongType) => {
    //     setaddToPlayListSong(song)
    //     setOpen(true)
    // }
    function setHoverData(data) {
        setSelectedSong(data);
    }
    let podcastid;
    if (router.query.id) podcastid = router.query.id;
    const { data: podcast } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "podcast_details",
        podcastid
    ], async ()=>await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .getPodcastDetails */ .WM)(podcastid));
    const { isSuccess, isLoading, isError, data, error, hasNextPage, fetchNextPage, isFetchingNextPage } = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useInfiniteQuery)([
        "podcastEpisodes",
        podcastid
    ], async ({ pageParam = 1 })=>await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .getPodcastEpisoes */ ._o)(podcastid, pageParam), {
        getNextPageParam: (lastPage, pages)=>{
            return lastPage.page + 1;
        }
    });
    async function requestAdditionOfPodcast() {
        try {
            await (0,_api__WEBPACK_IMPORTED_MODULE_5__/* .requestPodcastEpisodesPopulation */ .B7)(user?.id, podcastid);
            await queryClient.invalidateQueries([
                "podcastEpisodes",
                podcastid
            ]);
            setMessage("Podcast Episodes requested,We will try it as soon as possible");
            setopenSnack(true);
        } catch (error) {
            setMessage(`Podcast Episodes requested,Error ${error}`);
            setopenSnack(true);
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_NoSsr__WEBPACK_IMPORTED_MODULE_3___default()), {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                    p: 1,
                    sx: {
                        overflowY: "scroll",
                        overflowX: "hidden"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                            alignItems: "center",
                            columnGap: 3,
                            flexWrap: "nowrap",
                            className: "podcast_single",
                            sx: {
                                display: "flex",
                                flexDirection: {
                                    xs: "column",
                                    md: "row",
                                    lg: "row"
                                }
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                    sx: {
                                        background: "black"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: podcast?.image_url || "/cover.jpg",
                                        width: 200,
                                        height: 200
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                    sx: {
                                        display: "flex",
                                        rowGap: "8px",
                                        flexDirection: "column"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                            fontSize: "large",
                                            children: podcast?.title
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                            display: "flex",
                                            flexDirection: "column",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    color: "lightgrey",
                                                    fontSize: "small",
                                                    children: podcast?.genres
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    color: "lightgrey",
                                                    fontSize: "small",
                                                    children: [
                                                        podcast?.episode_count,
                                                        " episodes"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    color: "lightgrey",
                                                    fontSize: "small",
                                                    children: [
                                                        "By ",
                                                        podcast?.itunes_author
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                            sx: {
                                                columnGap: "1%"
                                            },
                                            display: "flex",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    size: "small",
                                                    fullWidth: false,
                                                    variant: "contained",
                                                    onClick: ()=>playEpisode(data?.pages[0]?.results[0]),
                                                    color: "secondary",
                                                    children: "Play Latest"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    size: "small",
                                                    fullWidth: false,
                                                    variant: "contained",
                                                    onClick: requestAdditionOfPodcast,
                                                    color: "secondary",
                                                    children: "Request"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                            fontSize: "small",
                                            color: "lightgrey",
                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .removeTags */ .av)(podcast?.description?.replace(/(href=["'])([A-Za-z-\\\/:.]*)(["'])/ig, "")) || ""
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                            mt: 2,
                            variant: "subtitle1",
                            className: "podcast_single_title",
                            children: "Episodes"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                            sx: {},
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                    sx: {
                                        display: "flex",
                                        flexDirection: "column",
                                        rowGap: "10px",
                                        maxHeight: 500,
                                        overflowY: "scroll"
                                    },
                                    children: data?.pages?.map((page)=>page.results?.map((song, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HoverableCard, {
                                                data: song,
                                                podcast: addedPodcast,
                                                addToWatchLater: addToWatchLater,
                                                playEpisode: playEpisode
                                            }, "podcast-episodes" + song.uuid + index)))
                                }),
                                hasNextPage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "btn-container",
                                    style: {
                                        textAlign: "center",
                                        marginTop: "2%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                        variant: "contained",
                                        onClick: ()=>fetchNextPage(),
                                        size: "small",
                                        sx: {
                                            color: "white",
                                            background: "purple",
                                            fontWeight: "bolder"
                                        },
                                        children: "Load More"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: isLoading && !isFetchingNextPage ? "Fetching..." : null
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Snackbar, {
                    anchorOrigin: {
                        vertical: "top",
                        horizontal: "right"
                    },
                    open: openSnack,
                    onClose: ()=>setopenSnack(false),
                    message: message,
                    autoHideDuration: 1500
                }, "snackbar")
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PodcastPage);
async function getServerSideProps(context) {
    let artistId = "";
    if (context.query.id) artistId = context.query.id;
    const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_2__.QueryClient();
    if (!queryClient.getQueryData([
        "podcastEpisodes",
        artistId
    ])) {
        await queryClient.prefetchInfiniteQuery([
            "podcastEpisodes",
            artistId
        ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_5__/* .getPodcastEpisoes */ ._o)(artistId, 1));
        await Promise.all([
            queryClient.prefetchQuery([
                "podcast_details",
                artistId
            ], async ()=>(0,_api__WEBPACK_IMPORTED_MODULE_5__/* .getPodcastDetails */ .WM)(artistId))
        ]);
    }
    return {
        props: {
            dehydratedState: JSON.parse(JSON.stringify((0,react_query__WEBPACK_IMPORTED_MODULE_2__.dehydrate)(queryClient)))
        }
    };
}
const HoverableCard = ({ data, podcast, addToWatchLater, playEpisode })=>{
    const active = podcast == data.uuid;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
        sx: {
            display: "flex",
            padding: "0.5%",
            alignItems: "flex-start",
            columnGap: "3%"
        },
        className: active ? "selected_podcast" : "playlist_song",
        onClick: ()=>playEpisode(data),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                flex: 0.2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: data.image_url ?? "/sample.jpg",
                    alt: "",
                    width: 80,
                    height: 80
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                sx: {
                    fontSize: "small",
                    display: "flex",
                    flexDirection: "column",
                    flex: 0.4
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                        sx: {
                            fontSize: "small"
                        },
                        children: data.name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                        sx: {
                            display: "inline",
                            color: "lightgray"
                        },
                        component: "span",
                        variant: "caption",
                        // color="text.primary"
                        fontSize: "x-small",
                        children: [
                            data?.date_published ? new Date(data?.date_published).toDateString() : "",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            data.duration ? (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .millisToMinutesAndSeconds */ .ut)(data.duration) : ""
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                flex: 1.5,
                sx: {
                    fontSize: "smaller",
                    textAlign: "justify",
                    color: "lightgray"
                },
                children: data.description?.length > 900 ? (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .removeTags */ .av)(data.description?.replace(/(href=["'])([A-Za-z-\\\/:.]*)(["'])/ig, "").slice(0, 900)) + " ..." : (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .removeTags */ .av)(data.description?.replace(/(href=["'])([A-Za-z-\\\/:.]*)(["'])/ig, ""))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    dangerouslySetInnerHTML: {
                        __html: data.description?.replace(/(href=["'])([A-Za-z-\\\/:.]*)(["'])/ig, "")
                    }
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_9___default()), {})
            })
        ]
    }, "podcast-episode-list" + data.uuid);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2321:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Addchart");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 9670:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FastForwardRounded");

/***/ }),

/***/ 1650:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FastRewindRounded");

/***/ }),

/***/ 7372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 1659:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HomeMax");

/***/ }),

/***/ 8792:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 6673:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PauseRounded");

/***/ }),

/***/ 5766:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlayArrowRounded");

/***/ }),

/***/ 3866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlaylistAdd");

/***/ }),

/***/ 907:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Podcasts");

/***/ }),

/***/ 340:
/***/ ((module) => {

module.exports = require("@mui/icons-material/QueueMusic");

/***/ }),

/***/ 3526:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Radio");

/***/ }),

/***/ 8017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 9044:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TrackChanges");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 9564:
/***/ ((module) => {

module.exports = require("@mui/material/Modal");

/***/ }),

/***/ 3534:
/***/ ((module) => {

module.exports = require("@mui/material/NoSsr");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 8924:
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 5918:
/***/ ((module) => {

module.exports = require("react-query/devtools");

/***/ }),

/***/ 4115:
/***/ ((module) => {

module.exports = import("@emotion/styled");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [940,556,178], () => (__webpack_exec__(1046)));
module.exports = __webpack_exports__;

})();